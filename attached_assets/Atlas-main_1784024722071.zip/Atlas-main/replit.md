# Study Tracker

A personal study progress tracker PWA for exam students. Tracks subjects, systems/modules, and completion checkboxes (Content, Qbank, 3 Revisions) — all stored locally in IndexedDB, no backend required.

## Run & Operate

- `pnpm --filter @workspace/study-tracker run dev` — run the frontend (served by workflow)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/study-tracker run typecheck` — typecheck frontend only

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 18 + Vite + Tailwind CSS + shadcn/ui
- Storage: Dexie.js (IndexedDB) — fully offline, no backend
- PWA: vite-plugin-pwa (auto-update service worker, installable on Android)
- Routing: wouter
- State: dexie-react-hooks `useLiveQuery`

## Where things live

- `artifacts/study-tracker/src/db/database.ts` — Dexie DB schema (subjects, systems tables)
- `artifacts/study-tracker/src/db/hooks.ts` — React hooks wrapping all Dexie queries
- `artifacts/study-tracker/src/pages/` — Home, SubjectDetail, Today, Search, Settings
- `artifacts/study-tracker/src/components/` — BottomNav, SubjectCard, SystemCard, etc.
- `artifacts/study-tracker/src/index.css` — full color palette (teal primary, light/dark modes)
- `artifacts/study-tracker/public/icons/` — PWA icons (192px, 512px)

## Architecture decisions

- **No backend** — everything stored in IndexedDB via Dexie.js; app works completely offline after install
- **useLiveQuery everywhere** — all UI reactivity comes from Dexie live queries, no separate React state for DB data
- **vite-plugin-pwa** — generates service worker and manifest; installable as PWA on Android
- **Wouter** — lightweight router; uses `import.meta.env.BASE_URL` for the base path

## Product

- Create subjects (e.g. Medicine, Surgery) and systems within them (e.g. CVS, Trauma)
- Track 5 checkboxes per system: Content, Qbank, Revision 1/2/3
- Mark weak areas (text notes) and status (Strong/Average/Weak) per system
- Home: overall progress %, subject progress cards
- Today: all incomplete tasks, auto-disappear when checked off
- Search: find subjects and systems instantly
- Settings: JSON export/import, delete all data, light/dark mode toggle

## User preferences

_Populate as you build._

## Gotchas

- No DATABASE_URL needed — this app uses IndexedDB, not PostgreSQL
- PWA icons live in `public/icons/` — must exist for manifest to resolve correctly
- Theme toggle adds/removes `.dark` class on `<html>` and persists to localStorage

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
