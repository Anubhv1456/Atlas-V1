import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';

import { BottomNav } from '@/components/BottomNav';
import Home from '@/pages/Home';
import SubjectDetail from '@/pages/SubjectDetail';
import Today from '@/pages/Today';
import History from '@/pages/History';
import Settings from '@/pages/Settings';

const queryClient = new QueryClient();

const initTheme = () => {
  if (typeof window !== 'undefined') {
    const isDark = localStorage.getItem('theme') === 'dark' ||
      (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }
};
initTheme();

function Router() {
  return (
    <div className="flex flex-col md:flex-row min-h-[100dvh] w-full">
      <BottomNav />
      <main className="flex-1 w-full relative">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/subjects/:id" component={SubjectDetail} />
          <Route path="/today" component={Today} />
          <Route path="/history" component={History} />
          <Route path="/settings" component={Settings} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
